
import sys as _sys

try:
	from ete3 import NCBITaxa
except ModuleNotFoundError as _e:
	if _e.name == "cgi":
		_sys.exit(
			"ete3 cannot be imported on Python "
			f"{_sys.version_info.major}.{_sys.version_info.minor}: it imports the "
			"standard library 'cgi' module, which was removed in Python 3.13.\n"
			"Install EukDetect with conda, whose ete3 build works on 3.13, or use "
			"Python 3.12 or earlier."
		)
	raise

import argparse
import textwrap
import sys
import os
import re
from collections import defaultdict
import logging

try:
	from . import ani_groups
	from . import reassign_eval
except ImportError:
	# Invoked as a script by the workflow, so there is no package context
	sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
	import ani_groups
	import reassign_eval


logging.basicConfig(
	format="%(asctime)s [%(levelname)s] %(message)s",
	datefmt="%Y-%m-%d %H:%M:%S",
	level=logging.INFO
)
logger = logging.getLogger(__name__)


_BUSCO_RE = re.compile(r"-(\d+at\d+)-")

NO_READS_MESSAGE = "Zero aligned reads in sample. Likely no eukaryotes present."
NO_TAXA_MESSAGE = "No taxa passing filter requirements."

NA = "NA"


def marker_busco_id(seq_name):
	if "Collapse" in seq_name:
		return "Collapsed"
	m = _BUSCO_RE.search(seq_name)
	return m.group(1) if m else "Unknown"


def marker_lengths_from_reference(ref_fasta, seq_taxid, seq_genomes,
								  species_primary_genomes):
	fai_path = ref_fasta + ".fai"
	if not os.path.exists(fai_path):
		logger.error(
			f"No .fai index found at {fai_path}. RPKS needs the full marker "
			f"length per taxon from the reference itself, not from a "
			f"precomputed file that can disagree with it or an observed-only "
			f"sum that shrinks at low coverage. Build it with:\n"
			f"    samtools faidx {ref_fasta}"
		)
		return {}, None

	seq_len = {}
	try:
		with open(fai_path) as f:
			for line in f:
				parts = line.rstrip("\n").split("\t")
				if len(parts) < 2:
					continue
				try:
					seq_len[parts[0]] = int(parts[1])
				except ValueError:
					continue
	except Exception as e:
		logger.error(f"Could not read {fai_path}: {e}")
		return {}, None

	if not seq_len:
		logger.error(f"{fai_path} is present but empty or unreadable.")
		return {}, None


	taxid_genome_seqs = defaultdict(lambda: defaultdict(list))
	missing = 0
	for seq, taxid in seq_taxid.items():
		if seq not in seq_len:
			missing += 1
			continue
		genome = seq_genomes.get(seq, "NA")
		taxid_genome_seqs[taxid][genome].append(seq)

	taxid_len = {}
	fallback_taxa = 0
	for taxid, genome_seqs in taxid_genome_seqs.items():
		primaries = [g for g in species_primary_genomes.get(taxid, [])
					 if g in genome_seqs]
		if not primaries:

			fallback_taxa += 1
			taxid_len[taxid] = sum(seq_len[s] for seqs in genome_seqs.values()
								   for s in seqs)
			continue

		total = 0
		covered_buscos = set()
		for genome in primaries:
			for seq in genome_seqs[genome]:
				total += seq_len[seq]
				b = marker_busco_id(seq)
				if b not in ("Collapsed", "Unknown"):
					covered_buscos.add(b)

		for genome, seqs in genome_seqs.items():
			if genome in primaries:
				continue
			for seq in sorted(seqs):
				b = marker_busco_id(seq)
				if b in ("Collapsed", "Unknown"):
					continue
				if b in covered_buscos:
					continue
				total += seq_len[seq]
				covered_buscos.add(b)

		taxid_len[taxid] = total

	if missing:
		logger.warning(
			f"{missing} markers in the taxid link file are absent from "
			f"{fai_path}; their length is not counted toward any taxon's "
			f"total. This usually means the .fai is stale relative to "
			f"busco_taxid_genome_link.txt -- rebuild it after any database "
			f"change with: samtools faidx {ref_fasta}"
		)
	if fallback_taxa:
		logger.debug(
			f"{fallback_taxa} taxa had no primary-genome selection to measure from "
			f"on and fell back to summing every genome assigned to them."
		)
	logger.info(
		f"Marker lengths for {len(taxid_len)} taxa summed from {fai_path} "
		f"({len(seq_len)} sequences indexed, {missing} link-table markers "
		f"not found there), using each taxon's primary genome as the "
		f"baseline plus any orthologs unique to its other genomes."
	)
	return taxid_len, missing


def main(argv):
	# Pipeline phases:
	# 1. Load inputs: NCBI taxonomy DB, gene lengths, busco-taxid-genome mappings, read counts
	# 2. Genome-level disambiguation: for species with multiple reference genomes, identify the
	#    primary genome (most reads/bases) and reassign reads from secondary genomes to it
	# 3. Genus-level disambiguation: within each genus, identify secondary species whose hits
	#    are better explained by the primary species, and reassign their reads
	# 4. Filter taxa (>=2 markers AND >=4 reads), compute RPKS-normalized relative abundance,
	#    and write output tables (alltab, primarytab, eukfrac)

	parser = argparse.ArgumentParser(
		description=textwrap.dedent("""\
			Summarize and filter alignments by taxid with multi-genome support.
			Uses read-based abundance with length normalization for universal markers.
			Required arguments are --dbfile, --taxid_link, 
			--readcounts, --primarytab, --eukfrac, --alltab
		"""),
		formatter_class = argparse.RawDescriptionHelpFormatter
	)
	parser.add_argument("--dbfile", type=str, required=True, help="Eukdetect database folder")
	parser.add_argument("--taxid_link", type=str, required=True, help="BUSCO to taxid to genome link file (3 columns)")
	parser.add_argument("--readcounts", type=str, required=True, help="Read counts and mismatches file")
	parser.add_argument("--eukfrac", type=str, required=True, help="Eukaryotic abundance & fraction output file")
	parser.add_argument("--primarytab", type=str, required=True, help="Table output of filtered hits")
	parser.add_argument("--alltab", type=str, required=True, help="Table output of all hits")
	parser.add_argument("--reference_fasta", type=str, required=True,
		help="Marker database FASTA (must have a .fai index alongside it: "
			 "samtools faidx <fasta>). RPKS is normalized by each taxon's "
			 "full marker complement summed from this index, rather than "
			 "from a precomputed file or from what happened to draw reads "
			 "this run.")
	parser.add_argument("--read_identities", type=str, required=True,
		help="Per-read identity table from read_identity.py, run on the same "
			 "q10-filtered BAM. Every proposed reassignment is tested against "
			 "these reads; there is no mode that skips this.")
	parser.add_argument("--reassignment_report", type=str, required=True,
		help="Where to write every reassignment decision and the numbers "
			 "behind it. Always written.")
	parser.add_argument("--ani_file", type=str, required=True,
		help="Genome ANI table: genome_1<TAB>genome_2<TAB>ANI, no header. "
			 "Species linked here are disambiguated against each other in "
			 "addition to those sharing an NCBI genus.")
	parser.add_argument("--ani_threshold", type=float, default=ani_groups.DEFAULT_ANI_THRESHOLD,
		help=argparse.SUPPRESS)

	files = parser.parse_args()

	#Fixed, not command-line options: see the DEFAULT_* constants in reassign_eval.py.
	logger.info(reassign_eval.describe_parameters())
	
	try:
		ncbi = NCBITaxa(files.dbfile)
		logger.info("Successfully loaded NCBI taxonomy database")
	except Exception as e:
		logger.error(f"Failed to load NCBI taxonomy database from {files.dbfile}: {e}")
		sys.exit(1)
	
	
	#Parse taxid_link file (busco, taxid, genome_id)
	taxid_seqs = defaultdict(list)
	full_seq_taxids = defaultdict(list)
	seq_taxids = {}
	seq_genomes = {}
	genome_taxids = defaultdict(set)
	
	try:
		with open(files.taxid_link) as f:
			for line in f:
				parts = line.strip().split('\t')
				if len(parts) < 2:
					continue
				seq = parts[0]
				taxid = parts[1]
				genome_id = parts[2] if (len(parts) > 2) else "NA"
				
				taxid_seqs[taxid].append(seq)
				seq_taxids[seq] = taxid
				seq_genomes[seq] = genome_id
				busco_match = re.findall(r'-\d+at\d+-', seq)
				if busco_match:
					busco = busco_match[0].strip('-')
					if busco not in full_seq_taxids[taxid]:
						full_seq_taxids[taxid].append(busco)
				# Needed to map ANI pairs, which are keyed on genome, onto the
				# taxids disambiguation works with.
				if genome_id != "NA":
					for g in genome_id.split(","):
						g = g.strip()
						if g:
							genome_taxids[g].add(taxid)
		logger.info(f"Loaded {len(seq_taxids)} sequence-to-taxid mappings")
	except FileNotFoundError:
		logger.error(f"Taxid link file not found: {files.taxid_link}")
		sys.exit(1)
	except Exception as e:
		logger.error(f"Error reading taxid link file: {e}")
		sys.exit(1)

	#RPKS is normalized by each taxon's full marker complement, using its
	#PRIMARY genome as the baseline (see marker_lengths_from_reference). That
	#needs species_primary_genomes, which the genome-level disambiguation pass
	#below computes; the call is placed after that pass, not here.

	#Parse read counts file
	taxid_counts = defaultdict(list)
	genome_counts = defaultdict(list)
	genuses = defaultdict(list)
	above_species = []
	counter = 0
	
	try:
		with open(files.readcounts) as countfile:
			countfile.readline()  #Skip header
			
			for line in countfile:
				counter += 1
				parts = line.strip().split('\t')
				if len(parts) < 8:
					logger.warning(f"Skipping malformed line {counter} in read counts file")
					continue
				
				seq = parts[0]
				
				#Check if sequence is in our mapping
				if seq not in seq_taxids:
					logger.warning(f"Sequence {seq} not found in taxid_link, skipping")
					continue
				
				try:
					count = int(parts[1])
					correct_bases = int(parts[2])
					#incorrect_bases = int(parts[3])
					total_bases = int(parts[4])
					subjlen = int(parts[5])
					coverage = float(parts[6])
					pid = float(parts[7])
				except (ValueError, IndexError) as e:
					logger.warning(f"Error parsing line {counter}: {e}, skipping")
					continue
				
				taxid = seq_taxids[seq]
				genome = seq_genomes.get(seq, "NA")
				
				#Extract BUSCO identifier
				if "Collapse" not in seq:
					busco_match = re.findall(r'-\d+at\d+-', seq)
					busco = busco_match[0].strip('-') if busco_match else "Unknown"
				else:
					busco = "Collapsed"
				
				#Determine genus
				try:
					lineage = ncbi.get_lineage(int(taxid))
					ranks = {value: key for (key, value) in ncbi.get_rank(lineage).items()}
					
					if 'genus' in ranks and 'Collapse' not in seq and "species" in ranks:
						genus = ranks['genus']
						if taxid not in genuses[genus]:
							genuses[genus].append(taxid)
					elif "SSCollapse" not in seq:
						above_species.append(taxid)
				except Exception as e:
					logger.warning(f"Could not get lineage for taxid {taxid}: {e}")
					continue

				seq_data = [seq, count, correct_bases, total_bases, subjlen, coverage, pid, busco]
				taxid_counts[taxid].append(seq_data)
				
				#Also track by genome
				if genome != "NA":
					genome_counts[(taxid, genome)].append(seq_data)
		
		logger.info(f"Processed {counter} alignment records")
	
	except FileNotFoundError:
		logger.error(f"Read counts file not found: {files.readcounts}")
		sys.exit(1)
	except Exception as e:
		logger.error(f"Error reading read counts file: {e}")
		sys.exit(1)
	
	#End if empty read count file
	if counter == 0:
		message = NO_READS_MESSAGE
		logger.warning(message)
		for outfile in [files.eukfrac, files.alltab, files.primarytab]:
			try:
				with open(outfile, 'w') as f:
					f.write(message + '\n')
			except Exception as e:
				logger.error(f"Error writing to {outfile}: {e}")
		reassign_eval.write_report(files.reassignment_report, [])
		sys.exit()

	#Calculate initial stats for each taxid
	logger.info("Calculating initial taxon coverage statistics.")
	taxon_coverage = {}
	seen_taxids = []
	taxon_observed_genomes = defaultdict(set)
	
	for tax in taxid_counts:
		mc = len(taxid_counts[tax])
		counts = sum(entry[1] for entry in taxid_counts[tax])
		correct = sum(entry[2] for entry in taxid_counts[tax])
		total_bases = sum(entry[3] for entry in taxid_counts[tax])
		subj_len = sum(entry[4] for entry in taxid_counts[tax])
		
		buscos = [entry[7] for entry in taxid_counts[tax] if len(entry[7]) > 1]
		
		#Collect genomes that had alignments for this taxid
		for entry in taxid_counts[tax]:
			seq = entry[0]
			genome_id = seq_genomes.get(seq, "NA")
			if genome_id != "NA":
				taxon_observed_genomes[tax].add(genome_id)
		
		percent_identity = round((correct / total_bases) * 100, 2) if total_bases > 0 else 0
		overall_coverage = round((total_bases / subj_len) * 100, 2) if subj_len > 0 else 0
		total_markers = len(taxid_seqs.get(tax, []))
		marker_percentage = round(mc / total_markers * 100, 2) if total_markers > 0 else 0
		
		seen_taxids.append(tax)
		
		taxon_coverage[tax] = [mc, counts, total_bases, marker_percentage, overall_coverage, 
							   percent_identity, subj_len, buscos, total_markers]
	
	
	#Store original (pre-reassignment) statistics for reporting
	#Format: [mc, counts, total_bases, marker_percentage, overall_coverage, 
	#		 percent_identity, subj_len, buscos, total_markers]
	original_taxon_stats = {tax: list(stats) for tax, stats in taxon_coverage.items()}
	
	logger.info("Starting genome-level disambiguation.")
	
	species_genome_mapping = defaultdict(lambda: defaultdict(dict))
	
	#For each species, collect stats per genome
	for (taxid, genome), seq_data_list in genome_counts.items():
		total_reads = sum(seq[1] for seq in seq_data_list)
		total_bases = sum(seq[3] for seq in seq_data_list)
		num_markers = len(seq_data_list)
		buscos = [seq[7] for seq in seq_data_list if len(seq[7]) > 1]
		
		#Calculate overall PID (weighted average by total bases)
		total_correct = sum(seq[2] for seq in seq_data_list)
		total_aligned = sum(seq[3] for seq in seq_data_list)
		overall_pid = (total_correct / total_aligned * 100) if total_aligned > 0 else 0.0
		
		species_genome_mapping[taxid][genome] = {
			'reads': total_reads,
			'bases': total_bases,
			'markers': num_markers,
			'buscos': buscos,
			'seq_data': seq_data_list,
			'overall_pid': overall_pid
		}
	
	species_primary_genomes = defaultdict(list)
	genome_secondary_to_primary = {}
	
	#For each species with multiple genomes, determine primary genome (can be multiple primary)
	for taxid, genomes_dict in species_genome_mapping.items():
		if len(genomes_dict) > 1:
			genome_list = list(genomes_dict.keys())
			reads_list = [genomes_dict[g]['reads'] for g in genome_list]
			bases_list = [genomes_dict[g]['bases'] for g in genome_list]
			
			maxreads = max(reads_list)
			maxbases = max(bases_list)
			primary_genomes = []
			
			#Determine primary genome
			if (reads_list.count(maxreads) == 1 and bases_list.count(maxbases) == 1 and
				reads_list.index(maxreads) == bases_list.index(maxbases)):
				max_genome = genome_list[reads_list.index(maxreads)]
				primary_genomes.append(max_genome)
			else:
				for i, g in enumerate(genome_list):
					if reads_list[i] == maxreads or bases_list[i] == maxbases:
						primary_genomes.append(g)
			
			species_primary_genomes[taxid] = primary_genomes
			
			#Check remaining genomes for secondary status
			secondary_genomes = [g for g in genome_list if g not in primary_genomes]
			
			for sec_genome in secondary_genomes:
				is_secondary = False
				responsible_primaries = []
				
				sec_buscos = genomes_dict[sec_genome]['buscos']
				sec_seq_data = genomes_dict[sec_genome]['seq_data']
				sec_overall_pid = genomes_dict[sec_genome]['overall_pid']
				
				for pri_genome in primary_genomes:
					pri_buscos = genomes_dict[pri_genome]['buscos']
					pri_seq_data = genomes_dict[pri_genome]['seq_data']
					pri_overall_pid = genomes_dict[pri_genome]['overall_pid']
					overlap = [b for b in sec_buscos if b in pri_buscos]
					
					#Compare overall PIDs regardless of overlap. If secondary has worse overall PID, it should be reassigned
					
					if len(overlap) == 0:
						#No shared BUSCOs
						#Check if secondary has worse overall PID than primary
						if sec_overall_pid <= pri_overall_pid:
							#Secondary has worse PID, reassign to primary
							is_secondary = True
							responsible_primaries.append(pri_genome)

					elif len(overlap) > 0:
						#Has overlap - check both overlapping PIDs and overall PID
						if sec_overall_pid <= pri_overall_pid:
							#Secondary has worse overall PID → reassign
							is_secondary = True
							responsible_primaries.append(pri_genome)
						else:
							#Secondary has better overall PID - check specific overlaps
							buscos_with_worse_or_equal_pid = []
							
							for busco in overlap:
								#Get PIDs for this BUSCO
								sec_pids = [s[6] for s in sec_seq_data if s[7] == busco]
								pri_pids = [s[6] for s in pri_seq_data if s[7] == busco]
								
								if len(pri_pids) > 0 and len(sec_pids) > 0:
									#Secondary has worse or equal PID on this BUSCO
									if sec_pids[0] <= pri_pids[0]:
										buscos_with_worse_or_equal_pid.append(busco)
							
							# Thresholding: secondary is reassigned if enough overlapping BUSCOs
							# have worse/equal PID vs primary. Strict threshold for sparse markers (<5).
							#Threshholding
							if len(sec_buscos) < 5:
								#Few markers: strict threshold
								if len(buscos_with_worse_or_equal_pid) >= 1:
									is_secondary = True
									responsible_primaries.append(pri_genome)
							else:
								#Many markers: lenient threshold
								if len(buscos_with_worse_or_equal_pid) > len(sec_buscos) / 2:
									is_secondary = True
									responsible_primaries.append(pri_genome)
				
				if is_secondary:
					genome_secondary_to_primary[(taxid, sec_genome)] = responsible_primaries
		else:
			#Only one genome for this species
			genome = list(genomes_dict.keys())[0]
			species_primary_genomes[taxid] = [genome]
	
	logger.info(f"Identified {len(genome_secondary_to_primary)} secondary genomes to reassign")
	
	reference_marker_length, _ = marker_lengths_from_reference(
		files.reference_fasta, seq_taxids, seq_genomes, species_primary_genomes
	)
	if not reference_marker_length:
		logger.error(
			"Cannot compute RPKS without per-taxon marker lengths from the "
			"reference FASTA index. See the error above for how to fix it."
		)
		sys.exit(1)
	
	#Reassign reads from secondary genomes to primary genomes
	genome_reassignment_details = defaultdict(lambda: {
		'reassigned_reads': 0,
		'reassigned_correct_bases': 0,
		'reassigned_total_bases': 0,
		'reassigned_marker_length': 0,
		'reassigned_from_genomes': set()
	})
	
	for (taxid, sec_genome), pri_genomes in genome_secondary_to_primary.items():
		sec_seq_data_list = species_genome_mapping[taxid][sec_genome]['seq_data']
		num_primaries = len(pri_genomes)
		
		#Build busco mapping for primary genomes
		primary_genome_buscos = {}
		for pri_genome in pri_genomes:
			primary_genome_buscos[pri_genome] = {}
			pri_seq_data_list = species_genome_mapping[taxid][pri_genome]['seq_data']
			for seq_data in pri_seq_data_list:
				marker_seq = seq_data[0]
				busco = seq_data[7]
				if busco not in primary_genome_buscos[pri_genome]:
					primary_genome_buscos[pri_genome][busco] = []
				primary_genome_buscos[pri_genome][busco].append(marker_seq)
		
		#Process each marker from secondary genome
		for seq_data in sec_seq_data_list:
			marker_seq = seq_data[0]
			busco = seq_data[7]
			count = seq_data[1]
			correct_bases = seq_data[2]
			total_bases = seq_data[3]
			marker_len = seq_data[4]
			
			reads_per_primary = count / num_primaries
			correct_per_primary = correct_bases / num_primaries
			total_per_primary = total_bases / num_primaries
			
			for pri_genome in pri_genomes:
				#Check if this busco exists in the primary genome
				busco_exists = (busco != "Collapsed" and len(busco) > 1 and 
							   busco in primary_genome_buscos[pri_genome])
				
				if busco_exists:
					#reassign reads to existing marker, dont add length
					target_marker = primary_genome_buscos[pri_genome][busco][0]
					
					marker_found = False
					for existing_seq_data in taxid_counts[taxid]:
						if existing_seq_data[0] == target_marker:
							existing_seq_data[1] += reads_per_primary
							existing_seq_data[2] += correct_per_primary
							existing_seq_data[3] += total_per_primary
							marker_found = True
							
							genome_reassignment_details[taxid]['reassigned_reads'] += reads_per_primary
							genome_reassignment_details[taxid]['reassigned_correct_bases'] += correct_per_primary
							genome_reassignment_details[taxid]['reassigned_total_bases'] += total_per_primary
							genome_reassignment_details[taxid]['reassigned_from_genomes'].add(sec_genome)
							break
					
					if not marker_found:
						new_seq = list(seq_data)
						new_seq[1] = reads_per_primary
						new_seq[2] = correct_per_primary
						new_seq[3] = total_per_primary
						taxid_counts[taxid].append(new_seq)
						
						genome_reassignment_details[taxid]['reassigned_reads'] += reads_per_primary
						genome_reassignment_details[taxid]['reassigned_correct_bases'] += correct_per_primary
						genome_reassignment_details[taxid]['reassigned_total_bases'] += total_per_primary
						genome_reassignment_details[taxid]['reassigned_marker_length'] += marker_len
						genome_reassignment_details[taxid]['reassigned_from_genomes'].add(sec_genome)
				else:
					#busco doesn't exist in primary genome, add full marker to total genome length
					new_seq = list(seq_data)
					new_seq[1] = reads_per_primary
					new_seq[2] = correct_per_primary
					new_seq[3] = total_per_primary
					taxid_counts[taxid].append(new_seq)
					
					genome_reassignment_details[taxid]['reassigned_reads'] += reads_per_primary
					genome_reassignment_details[taxid]['reassigned_correct_bases'] += correct_per_primary
					genome_reassignment_details[taxid]['reassigned_total_bases'] += total_per_primary
					genome_reassignment_details[taxid]['reassigned_marker_length'] += marker_len
					genome_reassignment_details[taxid]['reassigned_from_genomes'].add(sec_genome)
	

	logger.info("Recalculating taxon coverage after genome reassignment.")
	
	taxon_coverage = {}
	for tax in taxid_counts:
		mc = len(taxid_counts[tax])
		counts = sum(entry[1] for entry in taxid_counts[tax])
		correct = sum(entry[2] for entry in taxid_counts[tax])
		total_bases = sum(entry[3] for entry in taxid_counts[tax])
		subj_len = sum(entry[4] for entry in taxid_counts[tax])
		
		buscos = [entry[7] for entry in taxid_counts[tax] if len(entry[7]) > 1]
		
		percent_identity = round((correct / total_bases) * 100, 2) if total_bases > 0 else 0
		overall_coverage = round((total_bases / subj_len) * 100, 2) if subj_len > 0 else 0
		total_markers = len(taxid_seqs.get(tax, []))
		marker_percentage = round(mc / total_markers * 100, 2) if total_markers > 0 else 0
		
		taxon_coverage[tax] = [mc, counts, total_bases, marker_percentage, overall_coverage, 
							   percent_identity, subj_len, buscos, total_markers]

	logger.info("Starting genus and ANI disambiguation.")

	ani_pairs, _ = ani_groups.load_ani_pairs(files.ani_file, files.ani_threshold)
	if not ani_pairs:
		logger.warning(
			"No usable ANI pairs; disambiguation falls back to NCBI genus "
			"alone, which cannot compare species across genera."
		)
	disambig_groups, _ = ani_groups.group_species(
		genuses, genome_taxids, ani_pairs
	)

	primary = {}
	n_secondary = 0
	genus_secondary_to_primary = {}
	
	for genus, taxids in disambig_groups.items():
		if len(taxids) > 1:
			reads = [taxon_coverage[taxid][1] for taxid in taxids]
			bases = [taxon_coverage[taxid][2] for taxid in taxids]
			
			maxreads = max(reads)
			maxbases = max(bases)
			ptaxids = []
			
			#Determine primary taxids
			if (reads.count(maxreads) == 1 and bases.count(maxbases) == 1 and
				reads.index(maxreads) == bases.index(maxbases)):
				maxtax = taxids[reads.index(maxreads)]
				primary[maxtax] = taxon_coverage[maxtax][0:5]
				ptaxids.append(maxtax)
			else:
				for t in taxids:
					if taxon_coverage[t][1] == maxreads or taxon_coverage[t][2] == maxbases:
						ptaxids.append(t)
						primary[t] = taxon_coverage[t][0:5]
			
			#Check remaining taxids for secondary status
			unsorted_ataxids = [t for t in taxids if t not in ptaxids]
			ataxids = sorted(unsorted_ataxids, key=lambda x: taxon_coverage[x][1], reverse=True)
			
			for ataxid in ataxids:
				is_secondary = False
				responsible_primaries = []
				
				#Get secondary's overall PID
				sec_overall_pid = taxon_coverage[ataxid][5]
				
				for ptaxid in ptaxids:
					#Get primary's overall PID
					pri_overall_pid = taxon_coverage[ptaxid][5]
					
					p_buscos = full_seq_taxids.get(ptaxid, [])  # from taxid_link, in memory
					a_buscos = taxon_coverage[ataxid][7]
					a_remain = [b for b in a_buscos if b in p_buscos]

					
					if len(a_remain) == 0:
						#Check if secondary has worse overall PID than primary
						if sec_overall_pid <= pri_overall_pid:
							#Secondary has worse PID, reassign to primary
							is_secondary = True
							responsible_primaries.append(ptaxid)
					
					elif len(a_remain) > 0:
						#Has overlap - check both overall PID and overlapping PIDs
						if sec_overall_pid <= pri_overall_pid:
							#Secondary has worse overall PID, reassign
							is_secondary = True
							responsible_primaries.append(ptaxid)
						else:
							#Secondary has better overall PID - check specific overlaps
							a_above = []
							for b in a_remain:
								apid = [seq[6] for seq in taxid_counts[ataxid] if seq[7] == b]
								ppid = [seq[6] for seq in taxid_counts[ptaxid] if seq[7] == b]
								
								if len(ppid) > 0 and len(apid) > 0 and apid[0] >= ppid[0]:
									a_above.append(b)
								elif len(ppid) == 0:
									a_above.append(b)
							
							# Thresholding: mirror of genome-level logic — strict for sparse markers
							if len(a_buscos) < 5:
								if len(a_above) < len(a_buscos):
									is_secondary = True
									responsible_primaries.append(ptaxid)
							else:
								if len(a_above) <= len(a_buscos) / 2:
									is_secondary = True
									responsible_primaries.append(ptaxid)
				
				if is_secondary:
					n_secondary += 1
					genus_secondary_to_primary[ataxid] = responsible_primaries
				else:
					primary[ataxid] = taxon_coverage[ataxid][0:5]
		else:
			taxid = taxids[0]
			primary[taxid] = taxon_coverage[taxid][0:5]
	
	#Add above-species taxids
	for t in above_species:
		if t not in primary:
			primary[t] = taxon_coverage[t][0:5]
	
	logger.info(f"Genus-level: {len(primary)} primary taxa, {n_secondary} secondary taxa")

	filter_passing_taxids = []
	filter_failing_taxids = []
	for tax in primary:
		mc = taxon_coverage[tax][0]
		counts = taxon_coverage[tax][1]
		if int(mc) >= 2 and int(counts) >= 4:
			filter_passing_taxids.append(tax)
		else:
			filter_failing_taxids.append(tax)
	
	logger.info(f"Filtering: {len(filter_passing_taxids)} taxa passed, {len(filter_failing_taxids)} taxa failed")
	
	#Build genus to primary species mapping
	genus_to_primary_species = defaultdict(list)
	genus_to_all_species = defaultdict(list)
	
	for genus, taxids in disambig_groups.items():
		genus_to_all_species[genus] = taxids
		for taxid in taxids:
			if taxid in filter_passing_taxids:
				genus_to_primary_species[genus].append(taxid)
	
	#Extend secondary mapping to include all non-passing species in genus
	for genus in disambig_groups:
		if genus in genus_to_primary_species and len(genus_to_primary_species[genus]) > 0:
			primary_species_in_genus = genus_to_primary_species[genus]
			all_species_in_genus = genus_to_all_species[genus]
			
			for species in all_species_in_genus:
				if species not in filter_passing_taxids:
					if species not in genus_secondary_to_primary:
						genus_secondary_to_primary[species] = primary_species_in_genus

	#Re-evaluate every proposed reassignment against per-read evidence.
	#

	reassign_records = []
	by_taxid = reassign_eval.load_read_evidence(files.read_identities, seq_taxids)
	if not by_taxid:
		logger.error(
			f"No usable per-read evidence in {files.read_identities}; cannot "
			f"evaluate reassignment. Check that read_identity.py ran on the same "
			f"filtered BAM this run is using."
		)
		sys.exit(1)

	kept = []
	for sec_taxid in sorted(genus_secondary_to_primary):
		rec = reassign_eval.evaluate(
			sec_taxid, genus_secondary_to_primary[sec_taxid], by_taxid,
			marker_lengths=reference_marker_length,
		)
		reassign_records.append(rec)
		if rec["promote"]:
			kept.append(sec_taxid)
	for sec_taxid in kept:

		del genus_secondary_to_primary[sec_taxid]
		if sec_taxid not in filter_passing_taxids:
			filter_passing_taxids.append(sec_taxid)
	if reassign_records:
		logger.info(
			f"Read-level re-evaluation kept {len(kept)} of "
			f"{len(reassign_records)} proposed reassignments as separate species."
		)

	#Always written: the decision cannot be reconstructed from the tables.
	reassign_eval.write_report(files.reassignment_report, reassign_records)

	logger.info("Writing full read table.")
	
	marker_sorted = sorted(taxon_coverage.keys(), reverse=True, 
						  key=lambda x: taxon_coverage[x][3])
	
	try:
		with open(files.alltab, 'w') as dest:
			dest.write("Name\tTaxid\tRank\tObserved_markers\tRead_counts\t"
					  "Total_marker_coverage\tPercent_identity\tTotal_marker_length\t"
					  "Genomes\tFiltered\n")
			
			for tax in marker_sorted:
				try:
					rank = list(ncbi.get_rank([tax]).values())[0]
					name = list(ncbi.get_taxid_translator([tax]).values())[0]
				except Exception as e:
					logger.warning(f"Could not get rank/name for taxid {tax}: {e}")
					continue
				
				if rank == "no rank":
					try:
						parent = ncbi.get_lineage(tax)[-2]
						rank = list(ncbi.get_rank([parent]).values())[0]
					except:
						rank = "no rank"
				
				mc, counts, _, _, overall_coverage, percent_identity, _, _, _ = taxon_coverage[tax]

				#Same reference-derived length the primary table and RPKS use:
				#each taxon's primary assembly plus only the orthologs unique to
				#its other assemblies, summed from the .fai.
				blen = reference_marker_length.get(tax, 0)

				genomes = sorted(list(taxon_observed_genomes.get(tax, set())))
				genome_str = ",".join(genomes) if genomes else NA
				
				is_filtered = "No" if tax in filter_passing_taxids else "Yes"
				
				dest.write(f"{name}\t{tax}\t{rank}\t{mc}\t{counts}\t"
						  f"{overall_coverage}\t{percent_identity}\t{blen}\t"
						  f"{genome_str}\t{is_filtered}\n")
		
		logger.info(f"Wrote all taxa table to {files.alltab}")
	except Exception as e:
		logger.error(f"Error writing all taxa table: {e}")
		sys.exit(1)

	#if nothing passed filter, exit
	if len(filter_passing_taxids) == 0:
		message = NO_TAXA_MESSAGE
		logger.warning(message)
		for outfile in [files.primarytab, files.eukfrac]:
			try:
				with open(outfile, 'w') as f:
					f.write(message + '\n')
			except Exception as e:
				logger.error(f"Error writing to {outfile}: {e}")
		sys.exit()


	logger.info("Starting species-level reassignment.")
	
	species_reassignment_details = defaultdict(lambda: {
		'reassigned_reads': 0,
		'reassigned_correct_bases': 0,
		'reassigned_total_bases': 0,
		'reassigned_marker_length': 0,
		'reassigned_genomes': set()
	})
	
	#Build complete copy of taxid_counts before reassignment
	original_taxid_counts = {taxid: list(seqs) for taxid, seqs in taxid_counts.items()}
	
	for sec_taxid, pri_taxids in genus_secondary_to_primary.items():
		#Track genomes from secondary (filtered) taxids
		if sec_taxid in taxon_observed_genomes:
			for genome in taxon_observed_genomes[sec_taxid]:
				for pri_taxid in pri_taxids:
					species_reassignment_details[pri_taxid]['reassigned_genomes'].add(genome)
		
		#Get all sequences from secondary hit (use original counts)
		if sec_taxid not in original_taxid_counts:
			continue
			
		sec_seqs = original_taxid_counts[sec_taxid]
		
		#Calculate how to split reads among primaries
		num_primaries = len(pri_taxids)
		
		#Process each marker from the secondary taxid
		for seq_data in sec_seqs:
			marker_seq = seq_data[0]
			busco = seq_data[7]
			count = seq_data[1]
			correct_bases = seq_data[2]
			total_bases = seq_data[3]
			marker_len = seq_data[4]
			
			reads_per_primary = count / num_primaries
			correct_per_primary = correct_bases / num_primaries
			total_per_primary = total_bases / num_primaries
			
			#Distribute reads to primary taxids
			for pri_taxid in pri_taxids:
				#Initialize taxid_counts if needed
				if pri_taxid not in taxid_counts:
					taxid_counts[pri_taxid] = []
				
				#Check if this exact marker sequence already exists in the primary
				marker_found = False
				for existing_seq_data in taxid_counts[pri_taxid]:
					if existing_seq_data[0] == marker_seq:
						#Same marker sequence exists - add reads, not marker length
						existing_seq_data[1] += reads_per_primary
						existing_seq_data[2] += correct_per_primary
						existing_seq_data[3] += total_per_primary
						marker_found = True
						
						species_reassignment_details[pri_taxid]['reassigned_reads'] += reads_per_primary
						species_reassignment_details[pri_taxid]['reassigned_correct_bases'] += correct_per_primary
						species_reassignment_details[pri_taxid]['reassigned_total_bases'] += total_per_primary
						break
				
				if not marker_found:
					#Add reads and marker length
					reassigned_seq = list(seq_data)
					reassigned_seq[1] = reads_per_primary
					reassigned_seq[2] = correct_per_primary
					reassigned_seq[3] = total_per_primary
					taxid_counts[pri_taxid].append(reassigned_seq)
					
					species_reassignment_details[pri_taxid]['reassigned_reads'] += reads_per_primary
					species_reassignment_details[pri_taxid]['reassigned_correct_bases'] += correct_per_primary
					species_reassignment_details[pri_taxid]['reassigned_total_bases'] += total_per_primary
					species_reassignment_details[pri_taxid]['reassigned_marker_length'] += marker_len
	

	logger.info("Recalculating taxon coverage after species reassignment.")
	
	taxon_coverage = {}
	for tax in taxid_counts:
		mc = len(taxid_counts[tax])
		counts = sum(entry[1] for entry in taxid_counts[tax])
		correct = sum(entry[2] for entry in taxid_counts[tax])
		total_bases = sum(entry[3] for entry in taxid_counts[tax])
		subj_len = sum(entry[4] for entry in taxid_counts[tax])
		
		buscos = [entry[7] for entry in taxid_counts[tax] if len(entry[7]) > 1]
		
		percent_identity = round((correct / total_bases) * 100, 2) if total_bases > 0 else 0
		overall_coverage = round((total_bases / subj_len) * 100, 2) if subj_len > 0 else 0
		total_markers = len(taxid_seqs.get(tax, []))
		marker_percentage = round(mc / total_markers * 100, 2) if total_markers > 0 else 0
		
		taxon_coverage[tax] = [mc, counts, total_bases, marker_percentage, overall_coverage, 
							   percent_identity, subj_len, buscos, total_markers]
	

	logger.info("Building tree for filtered taxa.")
	
	try:
		tree = ncbi.get_topology(filter_passing_taxids)
		tree_root = tree.get_tree_root().name
		lineage = ncbi.get_lineage(tree_root)
		primary_tree_taxids = [int(e) for e in filter_passing_taxids] + lineage
		primary_tree = ncbi.get_topology(primary_tree_taxids, intermediate_nodes=True)
		logger.info("Tree built successfully")
	except Exception as e:
		logger.error(f"Error building filtered tree: {e}")
		sys.exit(1)

	logger.info("Calculating lineages and node statistics...")
	
	relab_levels = {'species': [], 'genus': [], 'family': [], 'order': [], 'class': [], 'phylum': []}
	ordered_labels = ["phylum", "class", "order", "family", "genus", "species"]
	lineages = {}
	
	node_total_reads = defaultdict(float)
	node_total_marker_length = defaultdict(float)

	#First pass: build lineages and collect data for all nodes in tree
	for node in primary_tree.traverse():
		try:
			lineage_list = ncbi.get_lineage(node.name)
			names = ncbi.get_taxid_translator(lineage_list)
			ranks = ncbi.get_rank(lineage_list)
			ranks_rev = {ranks[e]: e for e in ranks}
			
			lin_name = ""
			for label in ordered_labels:
				if label in ranks_rev:
					lin_name += f"{label}-{names[ranks_rev[label]]}|"
			lin_name = lin_name.strip('|').replace(' ', "_")
			lineages[node.name] = lin_name
			
			rank = list(ncbi.get_rank([node.name]).values())[0]
			
			if rank in relab_levels:
				relab_levels[rank].append(node.name)
		except Exception as e:
			logger.warning(f"Error processing node {node.name}: {e}")
			continue
		
		#For all filter-passing nodes, collect marker data post reassignment
		if node.name in filter_passing_taxids:
			if node.name in taxid_counts:
				for seq_data in taxid_counts[node.name]:
					node_total_reads[node.name] += seq_data[1]
					node_total_marker_length[node.name] += seq_data[4]

	node_original_marker_length = {}
	for tax in filter_passing_taxids:
		ref_len = reference_marker_length.get(tax, 0)
		if ref_len > 0:
			node_original_marker_length[tax] = ref_len
		else:
			#No reference length for this taxon (a link-table/.fai mismatch,
			#already warned about in marker_lengths_from_reference). Fall back to
			#the observed length rather than reporting zero.
			node_original_marker_length[tax] = node_total_marker_length.get(tax, 0)
	
	#Propagate markers and reads up the tree
	node_observed_genomes = defaultdict(set)
	
	for node in primary_tree.traverse("postorder"):
		#Only add genomes if this node passed filtering
		if node.name in filter_passing_taxids and node.name in taxon_observed_genomes:
			node_observed_genomes[node.name].update(taxon_observed_genomes[node.name])
		
		if not node.is_leaf():

			for child in node.children:
				#Propagate genomes up only from children that passed filtering
				if child.name in filter_passing_taxids and child.name in node_observed_genomes:
					node_observed_genomes[node.name].update(node_observed_genomes[child.name])
				
				#Sum reads and marker lengths from direct children
				if child.name in node_total_reads:
					node_total_reads[node.name] += node_total_reads[child.name]
					node_total_marker_length[node.name] += node_total_marker_length[child.name]
				
				#Sum original marker lengths from direct children
				if child.name in node_original_marker_length:
					if node.name not in node_original_marker_length:
						node_original_marker_length[node.name] = 0
					node_original_marker_length[node.name] += node_original_marker_length[child.name]

	# Remove taxonomic levels absent from some lineages to avoid
	# reporting inconsistent rank coverage across taxa (e.g. no "family" for some fungi)
	#Remove incomplete levels
	levels_to_remove = []
	for tax in filter_passing_taxids:
		lin = lineages.get(tax, "")
		groups = [l.split('-')[0] for l in lin.split('|')]
		levels = ordered_labels[0:len(groups)]
		if levels != groups:
			for l in levels:
				if l not in groups and l not in levels_to_remove:
					levels_to_remove.append(l)
	
	for l in levels_to_remove:
		relab_levels.pop(l, None)

	logger.info("Calculating normalized abundance (RPKS).")
	
	relabs = {}
	
	#Calculate RPKS for the lowest level with data
	lowest_rank = None
	for rank in reversed(ordered_labels):
		if rank in relab_levels and len(relab_levels[rank]) > 0:
			lowest_rank = rank
			break
	
	if lowest_rank:
		lowest_level_rpks = {}
		for tax in relab_levels[lowest_rank]:
			total_reads = node_total_reads.get(tax, 0)
			#Use ORIGINAL marker length to avoid penalty from sparse reassigned markers
			original_marker_length = node_original_marker_length.get(tax, 0)
			
			if original_marker_length > 0:
				# RPKS = reads per kilobase of marker sequence (length-normalized abundance)
				rpks = total_reads / (original_marker_length / 1000)
			else:
				rpks = 0.0
			
			lowest_level_rpks[tax] = rpks
		
		#Calculate total RPKS across all taxa at the lowest level for normalization
		total_rpks_lowest = sum(lowest_level_rpks.values())
		
		#Calculate relative abundance at lowest level
		for tax in relab_levels[lowest_rank]:
			rpks = lowest_level_rpks.get(tax, 0.0)
			
			if total_rpks_lowest > 0:
				rel_abundance = (rpks / total_rpks_lowest) * 100
			else:
				rel_abundance = 0.0
			
			total_reads = node_total_reads.get(tax, 0)
			original_marker_length = node_original_marker_length.get(tax, 0)

			relabs[tax] = [rpks, original_marker_length, rel_abundance, total_reads]

	#For all higher levels, sum the relative abundances of their children
	rank_order = [r for r in ordered_labels if r in relab_levels]
	
	for rank_idx in range(len(rank_order) - 2, -1, -1):
		rank = rank_order[rank_idx]
		child_rank = rank_order[rank_idx + 1] if rank_idx + 1 < len(rank_order) else None
		
		for tax in relab_levels[rank]:
			#Find all children of this taxon at the child rank
			if child_rank:
				children = []
				for child_tax in relab_levels[child_rank]:
					try:
						child_lineage = ncbi.get_lineage(int(child_tax))
						if int(tax) in child_lineage:
							children.append(child_tax)
					except:
						continue
				
				#Sum relative abundances from children
				rel_abundance = sum(relabs[child][2] for child in children if child in relabs)
			else:
				rel_abundance = 0.0
			
			total_reads = node_total_reads.get(tax, 0)
			#Use original marker length (sum of children's original lengths)
			original_marker_length = node_original_marker_length.get(tax, 0)
			
			if original_marker_length > 0:
				rpks = total_reads / (original_marker_length / 1000)
			else:
				rpks = 0.0

			relabs[tax] = [rpks, original_marker_length, rel_abundance, total_reads]

	logger.info("Writing primary table.")
	
	try:
		with open(files.primarytab, 'w') as dest:
			dest.write("Name\tRank\tLineage\tTaxid\tTotal_reads\tTotal_marker_length\t"
					  "Observed_marker_length\t"
					  "RPKS\tReads_aligned\tPID_aligned\tGenomes\t"
					  "Reads_reassigned\tPID_reassigned\tReassigned_genomes\n")
			
			for tax in filter_passing_taxids:
				try:
					lin = lineages.get(tax, list(ncbi.get_rank([tax]).values())[0])
					rank = list(ncbi.get_rank([tax]).values())[0]
					
					if rank == "no rank":
						parent = ncbi.get_lineage(tax)[-2]
						prevrank = list(ncbi.get_rank([parent]).values())[0]
						if prevrank == "species":
							rank = "species"
					
					name = list(ncbi.get_taxid_translator([tax]).values())[0]
				except Exception as e:
					logger.warning(f"Error getting info for taxid {tax}: {e}")
					continue
				
				#Get original alignment stats (before any reassignment)
				reads_original = original_taxon_stats[tax][1]  #read count
				pid_original = original_taxon_stats[tax][5]  #percent identity
				
				#Full marker complement from the reference index, same source
				#as the tree-based RPKS below. This table computes its own
				#RPKS separately from the tree-based one, so both have to use
				#the same length or the two outputs disagree with each other.
				total_genome_marker_length = reference_marker_length.get(
					tax, 0) or node_total_marker_length.get(tax, 0)
				
				#Combine genome-level and species-level reassignment details
				genome_reassigned_reads = genome_reassignment_details[tax]['reassigned_reads']
				genome_reassigned_correct = genome_reassignment_details[tax]['reassigned_correct_bases']
				genome_reassigned_total = genome_reassignment_details[tax]['reassigned_total_bases']
				genome_reassigned_genomes = genome_reassignment_details[tax]['reassigned_from_genomes']
				
				species_reassigned_reads = species_reassignment_details[tax]['reassigned_reads']
				species_reassigned_correct = species_reassignment_details[tax]['reassigned_correct_bases']
				species_reassigned_total = species_reassignment_details[tax]['reassigned_total_bases']
				species_reassigned_genomes = species_reassignment_details[tax]['reassigned_genomes']
				
				#Total reassigned reads and PID
				total_reassigned_reads = round(genome_reassigned_reads + species_reassigned_reads, 2)
				total_reassigned_correct = genome_reassigned_correct + species_reassigned_correct
				total_reassigned_total = genome_reassigned_total + species_reassigned_total
				
				reassigned_pid = round((total_reassigned_correct / total_reassigned_total) * 100, 2) if total_reassigned_total > 0 else NA
				
				#Build full list of reassigned genomes
				all_reassigned_genomes = sorted(list(genome_reassigned_genomes | species_reassigned_genomes))
				reassigned_genome_str = ",".join(all_reassigned_genomes) if all_reassigned_genomes else NA
				
				#RPKS over the full reference-derived marker length
				total_reads_all = reads_original + total_reassigned_reads
				rpks = round(total_reads_all / (total_genome_marker_length / 1000), 4) if total_genome_marker_length > 0 else 0.0
				
				#Get genomes detected for this taxid
				genomes = sorted(list(node_observed_genomes.get(tax, set())))
				genome_str = ",".join(genomes) if genomes else NA
				observed_len = int(node_total_marker_length.get(tax, 0))
				
				dest.write(f"{name}\t{rank}\t{lin}\t{tax}\t"
						  f"{round(total_reads_all, 2)}\t{int(total_genome_marker_length)}\t"
						  f"{observed_len}\t{rpks}\t"
						  f"{round(reads_original, 2)}\t{pid_original}\t{genome_str}\t"
						  f"{total_reassigned_reads}\t{reassigned_pid}\t{reassigned_genome_str}\n")
		
		logger.info(f"Wrote primary table to {files.primarytab}")
	except Exception as e:
		logger.error(f"Error writing primary table: {e}")
		sys.exit(1)
	
	logger.info("Writing relative abundance table.")
	
	try:
		with open(files.eukfrac, 'w') as dest:
			dest.write("Lineage\tRank\tName\tTaxID\tRPKS\t"
					  "Relative_abundance\tReads_total\tTotal_marker_length\tGenomes\n")
			
			for node in primary_tree.traverse("preorder"):
				try:
					rank = list(ncbi.get_rank([node.name]).values())[0]
					name = list(ncbi.get_taxid_translator([node.name]).values())[0]
					lin = lineages.get(node.name, rank)
				except Exception as e:
					logger.warning(f"Error getting info for node {node.name}: {e}")
					continue
				
				if rank == "no rank" and node.is_leaf():
					continue
				
				if node.name in relabs:
					#Only report RPKS for species-level taxa
					if rank == "species":
						rpks = round(relabs[node.name][0], 4)
					else:
						rpks = NA
					
					total_marker_length = int(relabs[node.name][1])
					rel_abundance = round(relabs[node.name][2], 4)
					total_reads = round(relabs[node.name][3], 2)
					
					genomes = sorted(list(node_observed_genomes.get(node.name, set())))
					genome_str = ",".join(genomes) if genomes else NA
					
					dest.write(f"{lin}\t{rank}\t{name}\t{node.name}\t{rpks}\t"
							  f"{rel_abundance}\t{total_reads}\t{total_marker_length}\t{genome_str}\n")
		
		logger.info(f"Wrote relative abundance table to {files.eukfrac}")
	except Exception as e:
		logger.error(f"Error writing relative abundance table: {e}")
		sys.exit(1)
	
	logger.info("Analysis complete!")


if __name__ == "__main__":
	main(sys.argv)

